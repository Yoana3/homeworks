package com.company;

public class Dog {
    public static void main(String[] args) {
        String dogname = "Tara";
        String breed = "English goldendoodle";
        String owner = "Elena Petkova";
        short hage = 3;
        float dage = 48.6f;
        String sex ="Female";
        String color="Apricot";
        String special = "Has dark markings";
        boolean partners = true;
        String partname = "Zeus";
        String partbreed = "English goldendoodle";
        boolean kids = true;
        byte puppies =6;
        String pupnames ="Ben, Sara, Ares, Tobby, Monkey, Yugi";
        System.out.println("Dog:"+dogname + "," +breed + "," +color);
        System.out.println("Belongs to:"+owner);
 }
}